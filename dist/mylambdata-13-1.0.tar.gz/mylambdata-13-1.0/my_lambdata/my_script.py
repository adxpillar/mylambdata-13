
import pandas 

from my_lambdata.my_mod import enlarge

print("HELLO WORLD")

df = pandas.DataFrame({"state": ["CT","CO", "CA", "TX"]})
print(df.head())

print(enlarge(9))