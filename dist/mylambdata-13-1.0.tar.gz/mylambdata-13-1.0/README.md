# mylambdata-13
lambdata package 

 ## Installation 

 ```sh
 pip install______ #to get address from pypi and update this line 
 ```


## Usage 
```py
from my_lambdata.my_mod import enlarge 

print(enlarge(9)) #> 900
```
